/* @settings */

console.log('@settings script running');

$('#logout').click(function(){
	_shutdown();
});

$('#reboot').click(function(){
	location.reload();
});