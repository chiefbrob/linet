/* @survival */ 

console.log('@survival script running');

var game = false;

$('#startgame').click(function(){
    if( !game )
    {
        alert('SURVIVAL GAME START');
        game = true;
    }
    else
    {
        alert('KEEP SURVIVING');
    }
});

$('#quitgame').click(function(){
    if( game )
    {
        alert('INTERNET IS BACK ONLINE');
        game = false;
    }
    else
    {
        alert('GAME NOT STARTED YET');
    }
});