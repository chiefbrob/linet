/* @wenzangu */

console.log('@wenzangu script running');