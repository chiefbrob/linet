/* @tumanashop */

console.log('@tumanashop script running');

$('.tumanashop-application').remove();

tumanashop = {
	all: false,
	installed: false,
};

function tumanashopAppStatus(username){
	for(var i =0; i<tumanashop.installed.length; i++)
	{
		var app = tumanashop.installed[i];

		if(app.username == username)
			return 'installed';
	}

	for(var i =0; i<tumanashop.all.length; i++)
	{
		var app = tumanashop.all[i];

		if(app.username == username)
			return 'exists';
	}

	return 'invalid';

}

function tumanashopAction(username){
	if(tumanashopAppStatus(username) == 'installed')
		return tunamashopUninstall(username);
	else
		return tumanashopInstall(username);
}

function tumanashopInstall(username){
	$.ajax({
		type: 'POST',
		url: 'api/install-application',
		data: {_token: _getToken(), username: username },
		success: function(response) {

			console.log(response);

			if(response[0] == 'LINET000'){
				alert('Kiumbe kiko tayari');

				var app = response[1];

				var $app = ''+
							'<div class="launcher-application" username="'+app.username+'">'+
				            	'<img src="images/icons/icon-'+app.icon+'.png" title="'+app.name+'" />'+
				                '<span>'+app.name+'</span>'+
				            '</div>';

				$('.launcher-applications').append($app);

				$('.launcher-application').click(function(){

					_runApp($(this).attr('username'));
					_components('win10-launcher','win10-componentMount',false);	
					_components('win10-notifications','win10-componentMount',false);	

				});
			}
			else
			{
				alert('Kiumbe hakijawekwa');
			}
				
		},
		error: function() {
			
			alert('Kiumbe hakijawekwa');
		},
	});
}
function tunamashopUninstall(username){
	$.ajax({
		type: 'POST',
		url: 'api/uninstall-application',
		data: {_token: _getToken(), username: username },
		success: function(response) {

			console.log(response);

			if(response[0] == 'LINET000'){

				alert('Kiumbe Kimetolewa');

				var app = response[1];

				$('.launcher-application').each(function(){
					if($(this).attr('username') == app.username)
						$(this.remove());
				});

			}
			else
			{
				alert('Kiumbe hakijatolewa');
			}
				
		},
		error: function() {
			
			alert('Kiumbe hakijatolewa');
		},
	});
}

function tumanashopWelcome(){
	$.ajax({
		type: 'POST',
		url: 'api/applications',
		data: {_token: _getToken() },
		success: function(response) {

			console.log(response);

			tumanashop.all = response['all'];

			tumanashop.installed = response['installed'];

			$('.tumanashop-application').remove();

			for(var i = 0; i<tumanashop.all.length; i++)
			{
				var app = tumanashop.all[i];

				var status = tumanashopAppStatus(app.username);



				var $app = ''+
				'<div username="'+app.username+'" class="tumanashop-application">'+
		            '<img src="images/icons/icon-'+app.icon+'.png">'+
		            '<h4>'+app.username+'</h4>';
		        if(status == 'installed')
		        	$app += '<button>Toa</button>';
		        else
		        	$app += '<button>Weka</button>';
		        $app += ''+
		        '</div>';

		        $('.tumanashop-welcome').append($app);


			}

			$('.tumanashop-application').children('button').click(function(){
				var username = $(this).parent().attr('username');
				tumanashopAction(username);
				tumanashopWelcome();
			});
				
		},
		error: function() {
			
			console.log('Failed to load applications');
		},
	});
}

tumanashopWelcome();

