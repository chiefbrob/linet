/* win10 script */
$().ready(function(){
	console.log("win10 script executing");
	
	var _linet = {
		launcher: false,
		notifications: false,
		taskbar: true,
		apps: ["mtengenezi","mwalimu","settings","tumanashop","ujumbe","wenzangu"],
		runApp: function(username){
			// #### runs an application
			console.log('applying ' + username);
			
			this.hideLauncher();
			$('.win10-application').each(function() {
                if($(this).attr('username') == username)
					$(this).removeClass('hidden');
				else
					$(this).addClass('hidden');
            });
			this.taskbarIcons("add",username);
		},
		stopApp: function(username){
			// #### stops the application
			console.log('stopping ' + username);

			this.taskbarIcons("remove",username);

			$('.win10-application').each(function() {
                if($(this).attr('username') == username)
					$(this).addClass('hidden');
            });
			
		},
		hideLauncher: function(){
			this.launcher = false;
			$('#win10-launcher').addClass('hidden');
		},
		showLauncher: function(){
			this.launcher = true;
			$('#win10-launcher').removeClass('hidden');
		},
		showNotifications: function(){
			this.notifications = true;
			$('#win10-notifications').removeClass('hidden');
		},
		hideNotifications: function(){
			this.notifications = false;
			$('#win10-notifications').addClass('hidden');
		},
		taskbarIcons: function(request, username){
			if(request == "add")
			{
				console.log('taskbar adding ' + username);
				
				var $app = '<img src="images/icons/icon-'+ username +'.png" class="icon" username="'+ username +'" title="'+ username +'" />';
				$('#win10-taskbar>.middle-section').append($app);
				$('#win10-taskbar>.middle-section>.app').click(function(){
					_linet.runApp($(this).attr('username'));
				});

			}

			if(request == "remove")
			{

				$('#win10-taskbar>.middle-section>img').each(function(){
									
					if($(this).attr('username') == username)
					{
						console.log('taskbar removing ' + username);
						
						$(this).remove();
					}
				});
			}
			
		}
	};

	$('#win10-start').click(function(){
		if(_linet.launcher)
			_linet.hideLauncher();
		else
			_linet.showLauncher();
		
	});
	
	$('#win10-nofiticationsButton').click(function(){
		if(_linet.notifications)
			_linet.hideNotifications();
		else
			_linet.showNotifications();
	});
	
	$('.notification-rudisha-ujumbe').click(function(){
		$(this).addClass('hidden');
		$(this).parent().children('.responder').each(function(){
			$(this).removeClass('hidden');
		});
		
	});
	
	$('#win10-notificationsClose').click(function(){
		_linet.hideNotifications();
	});
	
	$('.launcher-application').click(function(){
		_linet.runApp( $(this).attr('username') );
	});
	
	$('.win10-applicationCloseButton').click(function(){
		var u = $(this).parent().parent().attr("username");
		_linet.stopApp(u);
	});
	

});